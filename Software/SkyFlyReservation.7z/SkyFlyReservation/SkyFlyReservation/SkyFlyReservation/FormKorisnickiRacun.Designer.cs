﻿namespace SkyFlyReservation
{
    partial class FormKorisnickiRacun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KontaktLabel = new System.Windows.Forms.Label();
            this.KontaktTextBox = new System.Windows.Forms.TextBox();
            this.NatragButton = new System.Windows.Forms.Button();
            this.SpremiPromjeneButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UlogaTextBox = new System.Windows.Forms.TextBox();
            this.UlogaLabel = new System.Windows.Forms.Label();
            this.LozinkaTextBox = new System.Windows.Forms.TextBox();
            this.LozinkaLabel = new System.Windows.Forms.Label();
            this.KorImeTextBox = new System.Windows.Forms.TextBox();
            this.KorImeLabel = new System.Windows.Forms.Label();
            this.AdresaTextBox = new System.Windows.Forms.TextBox();
            this.AdresaLabel = new System.Windows.Forms.Label();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PrezimeTextBox = new System.Windows.Forms.TextBox();
            this.PrezimeLabel = new System.Windows.Forms.Label();
            this.ImeTextBox = new System.Windows.Forms.TextBox();
            this.ImeLabel = new System.Windows.Forms.Label();
            this.ShowButton = new System.Windows.Forms.Button();
            this.PromjeniLozinkuButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // KontaktLabel
            // 
            this.KontaktLabel.AutoSize = true;
            this.KontaktLabel.Location = new System.Drawing.Point(152, 146);
            this.KontaktLabel.Name = "KontaktLabel";
            this.KontaktLabel.Size = new System.Drawing.Size(47, 13);
            this.KontaktLabel.TabIndex = 51;
            this.KontaktLabel.Text = "Kontakt:";
            // 
            // KontaktTextBox
            // 
            this.KontaktTextBox.Location = new System.Drawing.Point(206, 143);
            this.KontaktTextBox.Name = "KontaktTextBox";
            this.KontaktTextBox.Size = new System.Drawing.Size(197, 20);
            this.KontaktTextBox.TabIndex = 50;
            // 
            // NatragButton
            // 
            this.NatragButton.Location = new System.Drawing.Point(309, 298);
            this.NatragButton.Name = "NatragButton";
            this.NatragButton.Size = new System.Drawing.Size(94, 35);
            this.NatragButton.TabIndex = 49;
            this.NatragButton.Text = "Natrag";
            this.NatragButton.UseVisualStyleBackColor = true;
            this.NatragButton.Click += new System.EventHandler(this.NatragButton_Click);
            // 
            // SpremiPromjeneButton
            // 
            this.SpremiPromjeneButton.Location = new System.Drawing.Point(209, 298);
            this.SpremiPromjeneButton.Name = "SpremiPromjeneButton";
            this.SpremiPromjeneButton.Size = new System.Drawing.Size(94, 35);
            this.SpremiPromjeneButton.TabIndex = 48;
            this.SpremiPromjeneButton.Text = "Spremi promjene";
            this.SpremiPromjeneButton.UseVisualStyleBackColor = true;
            this.SpremiPromjeneButton.Click += new System.EventHandler(this.SpremiPromjeneButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Korisnički račun";
            // 
            // UlogaTextBox
            // 
            this.UlogaTextBox.Location = new System.Drawing.Point(206, 272);
            this.UlogaTextBox.Name = "UlogaTextBox";
            this.UlogaTextBox.ReadOnly = true;
            this.UlogaTextBox.Size = new System.Drawing.Size(197, 20);
            this.UlogaTextBox.TabIndex = 45;
            // 
            // UlogaLabel
            // 
            this.UlogaLabel.AutoSize = true;
            this.UlogaLabel.Location = new System.Drawing.Point(162, 275);
            this.UlogaLabel.Name = "UlogaLabel";
            this.UlogaLabel.Size = new System.Drawing.Size(38, 13);
            this.UlogaLabel.TabIndex = 43;
            this.UlogaLabel.Text = "Uloga:";
            // 
            // LozinkaTextBox
            // 
            this.LozinkaTextBox.Location = new System.Drawing.Point(206, 221);
            this.LozinkaTextBox.Name = "LozinkaTextBox";
            this.LozinkaTextBox.ReadOnly = true;
            this.LozinkaTextBox.Size = new System.Drawing.Size(197, 20);
            this.LozinkaTextBox.TabIndex = 46;
            // 
            // LozinkaLabel
            // 
            this.LozinkaLabel.AutoSize = true;
            this.LozinkaLabel.Location = new System.Drawing.Point(153, 224);
            this.LozinkaLabel.Name = "LozinkaLabel";
            this.LozinkaLabel.Size = new System.Drawing.Size(47, 13);
            this.LozinkaLabel.TabIndex = 44;
            this.LozinkaLabel.Text = "Lozinka:";
            // 
            // KorImeTextBox
            // 
            this.KorImeTextBox.Location = new System.Drawing.Point(206, 195);
            this.KorImeTextBox.Name = "KorImeTextBox";
            this.KorImeTextBox.Size = new System.Drawing.Size(197, 20);
            this.KorImeTextBox.TabIndex = 42;
            // 
            // KorImeLabel
            // 
            this.KorImeLabel.AutoSize = true;
            this.KorImeLabel.Location = new System.Drawing.Point(122, 198);
            this.KorImeLabel.Name = "KorImeLabel";
            this.KorImeLabel.Size = new System.Drawing.Size(78, 13);
            this.KorImeLabel.TabIndex = 41;
            this.KorImeLabel.Text = "Korisničko ime:";
            // 
            // AdresaTextBox
            // 
            this.AdresaTextBox.Location = new System.Drawing.Point(206, 169);
            this.AdresaTextBox.Name = "AdresaTextBox";
            this.AdresaTextBox.Size = new System.Drawing.Size(197, 20);
            this.AdresaTextBox.TabIndex = 40;
            // 
            // AdresaLabel
            // 
            this.AdresaLabel.AutoSize = true;
            this.AdresaLabel.Location = new System.Drawing.Point(157, 172);
            this.AdresaLabel.Name = "AdresaLabel";
            this.AdresaLabel.Size = new System.Drawing.Size(43, 13);
            this.AdresaLabel.TabIndex = 39;
            this.AdresaLabel.Text = "Adresa:";
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Location = new System.Drawing.Point(206, 117);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(197, 20);
            this.EmailTextBox.TabIndex = 38;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(165, 120);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(35, 13);
            this.EmailLabel.TabIndex = 37;
            this.EmailLabel.Text = "Email:";
            // 
            // PrezimeTextBox
            // 
            this.PrezimeTextBox.Location = new System.Drawing.Point(207, 91);
            this.PrezimeTextBox.Name = "PrezimeTextBox";
            this.PrezimeTextBox.Size = new System.Drawing.Size(197, 20);
            this.PrezimeTextBox.TabIndex = 36;
            // 
            // PrezimeLabel
            // 
            this.PrezimeLabel.AutoSize = true;
            this.PrezimeLabel.Location = new System.Drawing.Point(153, 94);
            this.PrezimeLabel.Name = "PrezimeLabel";
            this.PrezimeLabel.Size = new System.Drawing.Size(47, 13);
            this.PrezimeLabel.TabIndex = 35;
            this.PrezimeLabel.Text = "Prezime:";
            // 
            // ImeTextBox
            // 
            this.ImeTextBox.Location = new System.Drawing.Point(206, 65);
            this.ImeTextBox.Name = "ImeTextBox";
            this.ImeTextBox.Size = new System.Drawing.Size(197, 20);
            this.ImeTextBox.TabIndex = 34;
            // 
            // ImeLabel
            // 
            this.ImeLabel.AutoSize = true;
            this.ImeLabel.Location = new System.Drawing.Point(173, 68);
            this.ImeLabel.Name = "ImeLabel";
            this.ImeLabel.Size = new System.Drawing.Size(27, 13);
            this.ImeLabel.TabIndex = 33;
            this.ImeLabel.Text = "Ime:";
            // 
            // ShowButton
            // 
            this.ShowButton.Location = new System.Drawing.Point(409, 221);
            this.ShowButton.Name = "ShowButton";
            this.ShowButton.Size = new System.Drawing.Size(23, 20);
            this.ShowButton.TabIndex = 52;
            this.ShowButton.Text = "0";
            this.ShowButton.UseVisualStyleBackColor = true;
            // 
            // PromjeniLozinkuButton
            // 
            this.PromjeniLozinkuButton.Location = new System.Drawing.Point(206, 247);
            this.PromjeniLozinkuButton.Name = "PromjeniLozinkuButton";
            this.PromjeniLozinkuButton.Size = new System.Drawing.Size(197, 20);
            this.PromjeniLozinkuButton.TabIndex = 53;
            this.PromjeniLozinkuButton.Text = "Promjeni lozinku";
            this.PromjeniLozinkuButton.UseVisualStyleBackColor = true;
            // 
            // FormKorisnickiRacun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 386);
            this.Controls.Add(this.PromjeniLozinkuButton);
            this.Controls.Add(this.ShowButton);
            this.Controls.Add(this.KontaktLabel);
            this.Controls.Add(this.KontaktTextBox);
            this.Controls.Add(this.NatragButton);
            this.Controls.Add(this.SpremiPromjeneButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UlogaTextBox);
            this.Controls.Add(this.UlogaLabel);
            this.Controls.Add(this.LozinkaTextBox);
            this.Controls.Add(this.LozinkaLabel);
            this.Controls.Add(this.KorImeTextBox);
            this.Controls.Add(this.KorImeLabel);
            this.Controls.Add(this.AdresaTextBox);
            this.Controls.Add(this.AdresaLabel);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.PrezimeTextBox);
            this.Controls.Add(this.PrezimeLabel);
            this.Controls.Add(this.ImeTextBox);
            this.Controls.Add(this.ImeLabel);
            this.Name = "FormKorisnickiRacun";
            this.Text = "FormKorisnickiRacun";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label KontaktLabel;
        private System.Windows.Forms.TextBox KontaktTextBox;
        private System.Windows.Forms.Button NatragButton;
        private System.Windows.Forms.Button SpremiPromjeneButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox UlogaTextBox;
        private System.Windows.Forms.Label UlogaLabel;
        private System.Windows.Forms.TextBox LozinkaTextBox;
        private System.Windows.Forms.Label LozinkaLabel;
        private System.Windows.Forms.TextBox KorImeTextBox;
        private System.Windows.Forms.Label KorImeLabel;
        private System.Windows.Forms.TextBox AdresaTextBox;
        private System.Windows.Forms.Label AdresaLabel;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox PrezimeTextBox;
        private System.Windows.Forms.Label PrezimeLabel;
        private System.Windows.Forms.TextBox ImeTextBox;
        private System.Windows.Forms.Label ImeLabel;
        private System.Windows.Forms.Button ShowButton;
        private System.Windows.Forms.Button PromjeniLozinkuButton;
    }
}