﻿namespace SkyFlyReservation
{
    partial class FormPocetna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PrijavaButton = new System.Windows.Forms.Button();
            this.RegistracijaButton = new System.Windows.Forms.Button();
            this.PregledLetovaButton = new System.Windows.Forms.Button();
            this.PregledRezervacijaButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.KupiButton = new System.Windows.Forms.Button();
            this.RezervirajButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PosaljiZahtjevButton = new System.Windows.Forms.Button();
            this.PregledZahtjevaButton = new System.Windows.Forms.Button();
            this.PregledIzvjescaButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PrijavaButton
            // 
            this.PrijavaButton.Location = new System.Drawing.Point(758, 12);
            this.PrijavaButton.Name = "PrijavaButton";
            this.PrijavaButton.Size = new System.Drawing.Size(108, 34);
            this.PrijavaButton.TabIndex = 0;
            this.PrijavaButton.Text = "Prijava";
            this.PrijavaButton.UseVisualStyleBackColor = true;
            // 
            // RegistracijaButton
            // 
            this.RegistracijaButton.Location = new System.Drawing.Point(644, 12);
            this.RegistracijaButton.Name = "RegistracijaButton";
            this.RegistracijaButton.Size = new System.Drawing.Size(108, 34);
            this.RegistracijaButton.TabIndex = 1;
            this.RegistracijaButton.Text = "Registracija";
            this.RegistracijaButton.UseVisualStyleBackColor = true;
            // 
            // PregledLetovaButton
            // 
            this.PregledLetovaButton.Location = new System.Drawing.Point(12, 12);
            this.PregledLetovaButton.Name = "PregledLetovaButton";
            this.PregledLetovaButton.Size = new System.Drawing.Size(108, 34);
            this.PregledLetovaButton.TabIndex = 2;
            this.PregledLetovaButton.Text = "PregledLetova";
            this.PregledLetovaButton.UseVisualStyleBackColor = true;
            // 
            // PregledRezervacijaButton
            // 
            this.PregledRezervacijaButton.Location = new System.Drawing.Point(126, 12);
            this.PregledRezervacijaButton.Name = "PregledRezervacijaButton";
            this.PregledRezervacijaButton.Size = new System.Drawing.Size(108, 34);
            this.PregledRezervacijaButton.TabIndex = 3;
            this.PregledRezervacijaButton.Text = "PregledRezervacija";
            this.PregledRezervacijaButton.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 96);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(854, 249);
            this.dataGridView1.TabIndex = 4;
            // 
            // KupiButton
            // 
            this.KupiButton.Location = new System.Drawing.Point(758, 351);
            this.KupiButton.Name = "KupiButton";
            this.KupiButton.Size = new System.Drawing.Size(108, 34);
            this.KupiButton.TabIndex = 5;
            this.KupiButton.Text = "Kupi";
            this.KupiButton.UseVisualStyleBackColor = true;
            // 
            // RezervirajButton
            // 
            this.RezervirajButton.Location = new System.Drawing.Point(644, 351);
            this.RezervirajButton.Name = "RezervirajButton";
            this.RezervirajButton.Size = new System.Drawing.Size(108, 34);
            this.RezervirajButton.TabIndex = 6;
            this.RezervirajButton.Text = "Rezerviraj";
            this.RezervirajButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 20);
            this.label1.TabIndex = 48;
            this.label1.Text = "Najpopularniji letovi:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(877, 60);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // PosaljiZahtjevButton
            // 
            this.PosaljiZahtjevButton.Location = new System.Drawing.Point(240, 12);
            this.PosaljiZahtjevButton.Name = "PosaljiZahtjevButton";
            this.PosaljiZahtjevButton.Size = new System.Drawing.Size(108, 34);
            this.PosaljiZahtjevButton.TabIndex = 50;
            this.PosaljiZahtjevButton.Text = "Pošalji zahtjev";
            this.PosaljiZahtjevButton.UseVisualStyleBackColor = true;
            // 
            // PregledZahtjevaButton
            // 
            this.PregledZahtjevaButton.Location = new System.Drawing.Point(468, 12);
            this.PregledZahtjevaButton.Name = "PregledZahtjevaButton";
            this.PregledZahtjevaButton.Size = new System.Drawing.Size(108, 34);
            this.PregledZahtjevaButton.TabIndex = 51;
            this.PregledZahtjevaButton.Text = "Pregld zahtjeva";
            this.PregledZahtjevaButton.UseVisualStyleBackColor = true;
            // 
            // PregledIzvjescaButton
            // 
            this.PregledIzvjescaButton.Location = new System.Drawing.Point(354, 12);
            this.PregledIzvjescaButton.Name = "PregledIzvjescaButton";
            this.PregledIzvjescaButton.Size = new System.Drawing.Size(108, 34);
            this.PregledIzvjescaButton.TabIndex = 52;
            this.PregledIzvjescaButton.Text = "Pregld izvjesca";
            this.PregledIzvjescaButton.UseVisualStyleBackColor = true;
            // 
            // FormPocetna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 417);
            this.Controls.Add(this.PregledIzvjescaButton);
            this.Controls.Add(this.PregledZahtjevaButton);
            this.Controls.Add(this.PosaljiZahtjevButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RezervirajButton);
            this.Controls.Add(this.KupiButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.PregledRezervacijaButton);
            this.Controls.Add(this.PregledLetovaButton);
            this.Controls.Add(this.RegistracijaButton);
            this.Controls.Add(this.PrijavaButton);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormPocetna";
            this.Text = "Pocetna";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PrijavaButton;
        private System.Windows.Forms.Button RegistracijaButton;
        private System.Windows.Forms.Button PregledLetovaButton;
        private System.Windows.Forms.Button PregledRezervacijaButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button KupiButton;
        private System.Windows.Forms.Button RezervirajButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button PosaljiZahtjevButton;
        private System.Windows.Forms.Button PregledZahtjevaButton;
        private System.Windows.Forms.Button PregledIzvjescaButton;
    }
}