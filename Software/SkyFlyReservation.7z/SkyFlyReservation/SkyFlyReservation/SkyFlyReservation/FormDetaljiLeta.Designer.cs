﻿namespace SkyFlyReservation
{
    partial class FormDetaljiLeta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDetaljiLeta));
            this.cijenaKarteTextBox = new System.Windows.Forms.TextBox();
            this.cijenaKarteLabel = new System.Windows.Forms.Label();
            this.vrijemeDolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemeDolaskaLabel = new System.Windows.Forms.Label();
            this.vrijemePolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemePolaskaLabel = new System.Windows.Forms.Label();
            this.avionNaLetuTextBox = new System.Windows.Forms.TextBox();
            this.avionNaLetuLabel = new System.Windows.Forms.Label();
            this.odabraniOdredisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniOdredisniLabel = new System.Windows.Forms.Label();
            this.odabraniPolazisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniPolazisniLabel = new System.Windows.Forms.Label();
            this.oznakaOdabranogLetaLabel = new System.Windows.Forms.Label();
            this.detaljiLetaLabel = new System.Windows.Forms.Label();
            this.zatvoriButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cijenaKarteTextBox
            // 
            this.cijenaKarteTextBox.Enabled = false;
            this.cijenaKarteTextBox.Location = new System.Drawing.Point(54, 411);
            this.cijenaKarteTextBox.Name = "cijenaKarteTextBox";
            this.cijenaKarteTextBox.ReadOnly = true;
            this.cijenaKarteTextBox.Size = new System.Drawing.Size(200, 22);
            this.cijenaKarteTextBox.TabIndex = 28;
            // 
            // cijenaKarteLabel
            // 
            this.cijenaKarteLabel.AutoSize = true;
            this.cijenaKarteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cijenaKarteLabel.Location = new System.Drawing.Point(51, 391);
            this.cijenaKarteLabel.Name = "cijenaKarteLabel";
            this.cijenaKarteLabel.Size = new System.Drawing.Size(91, 17);
            this.cijenaKarteLabel.TabIndex = 27;
            this.cijenaKarteLabel.Text = "Cijena karte :";
            // 
            // vrijemeDolaskaTextBox
            // 
            this.vrijemeDolaskaTextBox.Enabled = false;
            this.vrijemeDolaskaTextBox.Location = new System.Drawing.Point(54, 348);
            this.vrijemeDolaskaTextBox.Name = "vrijemeDolaskaTextBox";
            this.vrijemeDolaskaTextBox.ReadOnly = true;
            this.vrijemeDolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemeDolaskaTextBox.TabIndex = 26;
            // 
            // vrijemeDolaskaLabel
            // 
            this.vrijemeDolaskaLabel.AutoSize = true;
            this.vrijemeDolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemeDolaskaLabel.Location = new System.Drawing.Point(51, 327);
            this.vrijemeDolaskaLabel.Name = "vrijemeDolaskaLabel";
            this.vrijemeDolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemeDolaskaLabel.TabIndex = 25;
            this.vrijemeDolaskaLabel.Text = "Vrijeme dolaska :";
            // 
            // vrijemePolaskaTextBox
            // 
            this.vrijemePolaskaTextBox.Enabled = false;
            this.vrijemePolaskaTextBox.Location = new System.Drawing.Point(54, 284);
            this.vrijemePolaskaTextBox.Name = "vrijemePolaskaTextBox";
            this.vrijemePolaskaTextBox.ReadOnly = true;
            this.vrijemePolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemePolaskaTextBox.TabIndex = 24;
            // 
            // vrijemePolaskaLabel
            // 
            this.vrijemePolaskaLabel.AutoSize = true;
            this.vrijemePolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemePolaskaLabel.Location = new System.Drawing.Point(51, 264);
            this.vrijemePolaskaLabel.Name = "vrijemePolaskaLabel";
            this.vrijemePolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemePolaskaLabel.TabIndex = 23;
            this.vrijemePolaskaLabel.Text = "Vrijeme polaska :";
            // 
            // avionNaLetuTextBox
            // 
            this.avionNaLetuTextBox.Enabled = false;
            this.avionNaLetuTextBox.Location = new System.Drawing.Point(54, 220);
            this.avionNaLetuTextBox.Name = "avionNaLetuTextBox";
            this.avionNaLetuTextBox.ReadOnly = true;
            this.avionNaLetuTextBox.Size = new System.Drawing.Size(200, 22);
            this.avionNaLetuTextBox.TabIndex = 22;
            // 
            // avionNaLetuLabel
            // 
            this.avionNaLetuLabel.AutoSize = true;
            this.avionNaLetuLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.avionNaLetuLabel.Location = new System.Drawing.Point(51, 200);
            this.avionNaLetuLabel.Name = "avionNaLetuLabel";
            this.avionNaLetuLabel.Size = new System.Drawing.Size(98, 17);
            this.avionNaLetuLabel.TabIndex = 21;
            this.avionNaLetuLabel.Text = "Avion na letu :";
            // 
            // odabraniOdredisniTextBox
            // 
            this.odabraniOdredisniTextBox.Enabled = false;
            this.odabraniOdredisniTextBox.Location = new System.Drawing.Point(54, 157);
            this.odabraniOdredisniTextBox.Name = "odabraniOdredisniTextBox";
            this.odabraniOdredisniTextBox.ReadOnly = true;
            this.odabraniOdredisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniOdredisniTextBox.TabIndex = 20;
            // 
            // odabraniOdredisniLabel
            // 
            this.odabraniOdredisniLabel.AutoSize = true;
            this.odabraniOdredisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniOdredisniLabel.Location = new System.Drawing.Point(51, 136);
            this.odabraniOdredisniLabel.Name = "odabraniOdredisniLabel";
            this.odabraniOdredisniLabel.Size = new System.Drawing.Size(142, 17);
            this.odabraniOdredisniLabel.TabIndex = 19;
            this.odabraniOdredisniLabel.Text = "Odredišni aerodrom :";
            // 
            // odabraniPolazisniTextBox
            // 
            this.odabraniPolazisniTextBox.Enabled = false;
            this.odabraniPolazisniTextBox.Location = new System.Drawing.Point(54, 94);
            this.odabraniPolazisniTextBox.Name = "odabraniPolazisniTextBox";
            this.odabraniPolazisniTextBox.ReadOnly = true;
            this.odabraniPolazisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniPolazisniTextBox.TabIndex = 18;
            // 
            // odabraniPolazisniLabel
            // 
            this.odabraniPolazisniLabel.AutoSize = true;
            this.odabraniPolazisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniPolazisniLabel.Location = new System.Drawing.Point(51, 73);
            this.odabraniPolazisniLabel.Name = "odabraniPolazisniLabel";
            this.odabraniPolazisniLabel.Size = new System.Drawing.Size(137, 17);
            this.odabraniPolazisniLabel.TabIndex = 17;
            this.odabraniPolazisniLabel.Text = "Polazišni aerodrom :";
            // 
            // oznakaOdabranogLetaLabel
            // 
            this.oznakaOdabranogLetaLabel.AutoSize = true;
            this.oznakaOdabranogLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oznakaOdabranogLetaLabel.Location = new System.Drawing.Point(149, 30);
            this.oznakaOdabranogLetaLabel.Name = "oznakaOdabranogLetaLabel";
            this.oznakaOdabranogLetaLabel.Size = new System.Drawing.Size(0, 24);
            this.oznakaOdabranogLetaLabel.TabIndex = 16;
            // 
            // detaljiLetaLabel
            // 
            this.detaljiLetaLabel.AutoSize = true;
            this.detaljiLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.detaljiLetaLabel.Location = new System.Drawing.Point(37, 30);
            this.detaljiLetaLabel.Name = "detaljiLetaLabel";
            this.detaljiLetaLabel.Size = new System.Drawing.Size(106, 24);
            this.detaljiLetaLabel.TabIndex = 15;
            this.detaljiLetaLabel.Text = "Detalji leta";
            // 
            // zatvoriButton
            // 
            this.zatvoriButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.zatvoriButton.Location = new System.Drawing.Point(104, 449);
            this.zatvoriButton.Name = "zatvoriButton";
            this.zatvoriButton.Size = new System.Drawing.Size(89, 34);
            this.zatvoriButton.TabIndex = 29;
            this.zatvoriButton.Text = "Zatvori";
            this.zatvoriButton.UseVisualStyleBackColor = true;
            this.zatvoriButton.Click += new System.EventHandler(this.zatvoriButton_Click);
            // 
            // FormDetaljiLeta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 496);
            this.Controls.Add(this.zatvoriButton);
            this.Controls.Add(this.cijenaKarteTextBox);
            this.Controls.Add(this.cijenaKarteLabel);
            this.Controls.Add(this.vrijemeDolaskaTextBox);
            this.Controls.Add(this.vrijemeDolaskaLabel);
            this.Controls.Add(this.vrijemePolaskaTextBox);
            this.Controls.Add(this.vrijemePolaskaLabel);
            this.Controls.Add(this.avionNaLetuTextBox);
            this.Controls.Add(this.avionNaLetuLabel);
            this.Controls.Add(this.odabraniOdredisniTextBox);
            this.Controls.Add(this.odabraniOdredisniLabel);
            this.Controls.Add(this.odabraniPolazisniTextBox);
            this.Controls.Add(this.odabraniPolazisniLabel);
            this.Controls.Add(this.oznakaOdabranogLetaLabel);
            this.Controls.Add(this.detaljiLetaLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormDetaljiLeta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalji leta";
            this.Load += new System.EventHandler(this.FormDetaljiLeta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox cijenaKarteTextBox;
        private System.Windows.Forms.Label cijenaKarteLabel;
        private System.Windows.Forms.TextBox vrijemeDolaskaTextBox;
        private System.Windows.Forms.Label vrijemeDolaskaLabel;
        private System.Windows.Forms.TextBox vrijemePolaskaTextBox;
        private System.Windows.Forms.Label vrijemePolaskaLabel;
        private System.Windows.Forms.TextBox avionNaLetuTextBox;
        private System.Windows.Forms.Label avionNaLetuLabel;
        private System.Windows.Forms.TextBox odabraniOdredisniTextBox;
        private System.Windows.Forms.Label odabraniOdredisniLabel;
        private System.Windows.Forms.TextBox odabraniPolazisniTextBox;
        private System.Windows.Forms.Label odabraniPolazisniLabel;
        private System.Windows.Forms.Label oznakaOdabranogLetaLabel;
        private System.Windows.Forms.Label detaljiLetaLabel;
        private System.Windows.Forms.Button zatvoriButton;
    }
}