﻿namespace SkyFlyReservation
{
    partial class FormObrisiLet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormObrisiLet));
            this.odustaniButton = new System.Windows.Forms.Button();
            this.vrijemeDolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemeDolaskaLabel = new System.Windows.Forms.Label();
            this.vrijemePolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemePolaskaLabel = new System.Windows.Forms.Label();
            this.avionNaLetuTextBox = new System.Windows.Forms.TextBox();
            this.avionNaLetuLabel = new System.Windows.Forms.Label();
            this.odabraniOdredisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniOdredisniLabel = new System.Windows.Forms.Label();
            this.odabraniPolazisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniPolazisniLabel = new System.Windows.Forms.Label();
            this.oznakaOdabranogLetaLabel = new System.Windows.Forms.Label();
            this.detaljiLetaLabel = new System.Windows.Forms.Label();
            this.obrisiLetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // odustaniButton
            // 
            this.odustaniButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odustaniButton.Location = new System.Drawing.Point(174, 390);
            this.odustaniButton.Name = "odustaniButton";
            this.odustaniButton.Size = new System.Drawing.Size(89, 34);
            this.odustaniButton.TabIndex = 44;
            this.odustaniButton.Text = "Odustani";
            this.odustaniButton.UseVisualStyleBackColor = true;
            this.odustaniButton.Click += new System.EventHandler(this.odustaniButton_Click);
            // 
            // vrijemeDolaskaTextBox
            // 
            this.vrijemeDolaskaTextBox.Enabled = false;
            this.vrijemeDolaskaTextBox.Location = new System.Drawing.Point(63, 340);
            this.vrijemeDolaskaTextBox.Name = "vrijemeDolaskaTextBox";
            this.vrijemeDolaskaTextBox.ReadOnly = true;
            this.vrijemeDolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemeDolaskaTextBox.TabIndex = 41;
            // 
            // vrijemeDolaskaLabel
            // 
            this.vrijemeDolaskaLabel.AutoSize = true;
            this.vrijemeDolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemeDolaskaLabel.Location = new System.Drawing.Point(60, 319);
            this.vrijemeDolaskaLabel.Name = "vrijemeDolaskaLabel";
            this.vrijemeDolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemeDolaskaLabel.TabIndex = 40;
            this.vrijemeDolaskaLabel.Text = "Vrijeme dolaska :";
            // 
            // vrijemePolaskaTextBox
            // 
            this.vrijemePolaskaTextBox.Enabled = false;
            this.vrijemePolaskaTextBox.Location = new System.Drawing.Point(63, 276);
            this.vrijemePolaskaTextBox.Name = "vrijemePolaskaTextBox";
            this.vrijemePolaskaTextBox.ReadOnly = true;
            this.vrijemePolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemePolaskaTextBox.TabIndex = 39;
            // 
            // vrijemePolaskaLabel
            // 
            this.vrijemePolaskaLabel.AutoSize = true;
            this.vrijemePolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemePolaskaLabel.Location = new System.Drawing.Point(60, 256);
            this.vrijemePolaskaLabel.Name = "vrijemePolaskaLabel";
            this.vrijemePolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemePolaskaLabel.TabIndex = 38;
            this.vrijemePolaskaLabel.Text = "Vrijeme polaska :";
            // 
            // avionNaLetuTextBox
            // 
            this.avionNaLetuTextBox.Enabled = false;
            this.avionNaLetuTextBox.Location = new System.Drawing.Point(63, 212);
            this.avionNaLetuTextBox.Name = "avionNaLetuTextBox";
            this.avionNaLetuTextBox.ReadOnly = true;
            this.avionNaLetuTextBox.Size = new System.Drawing.Size(200, 22);
            this.avionNaLetuTextBox.TabIndex = 37;
            // 
            // avionNaLetuLabel
            // 
            this.avionNaLetuLabel.AutoSize = true;
            this.avionNaLetuLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.avionNaLetuLabel.Location = new System.Drawing.Point(60, 192);
            this.avionNaLetuLabel.Name = "avionNaLetuLabel";
            this.avionNaLetuLabel.Size = new System.Drawing.Size(98, 17);
            this.avionNaLetuLabel.TabIndex = 36;
            this.avionNaLetuLabel.Text = "Avion na letu :";
            // 
            // odabraniOdredisniTextBox
            // 
            this.odabraniOdredisniTextBox.Enabled = false;
            this.odabraniOdredisniTextBox.Location = new System.Drawing.Point(63, 149);
            this.odabraniOdredisniTextBox.Name = "odabraniOdredisniTextBox";
            this.odabraniOdredisniTextBox.ReadOnly = true;
            this.odabraniOdredisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniOdredisniTextBox.TabIndex = 35;
            // 
            // odabraniOdredisniLabel
            // 
            this.odabraniOdredisniLabel.AutoSize = true;
            this.odabraniOdredisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniOdredisniLabel.Location = new System.Drawing.Point(60, 128);
            this.odabraniOdredisniLabel.Name = "odabraniOdredisniLabel";
            this.odabraniOdredisniLabel.Size = new System.Drawing.Size(142, 17);
            this.odabraniOdredisniLabel.TabIndex = 34;
            this.odabraniOdredisniLabel.Text = "Odredišni aerodrom :";
            // 
            // odabraniPolazisniTextBox
            // 
            this.odabraniPolazisniTextBox.Enabled = false;
            this.odabraniPolazisniTextBox.Location = new System.Drawing.Point(63, 86);
            this.odabraniPolazisniTextBox.Name = "odabraniPolazisniTextBox";
            this.odabraniPolazisniTextBox.ReadOnly = true;
            this.odabraniPolazisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniPolazisniTextBox.TabIndex = 33;
            // 
            // odabraniPolazisniLabel
            // 
            this.odabraniPolazisniLabel.AutoSize = true;
            this.odabraniPolazisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniPolazisniLabel.Location = new System.Drawing.Point(60, 65);
            this.odabraniPolazisniLabel.Name = "odabraniPolazisniLabel";
            this.odabraniPolazisniLabel.Size = new System.Drawing.Size(137, 17);
            this.odabraniPolazisniLabel.TabIndex = 32;
            this.odabraniPolazisniLabel.Text = "Polazišni aerodrom :";
            // 
            // oznakaOdabranogLetaLabel
            // 
            this.oznakaOdabranogLetaLabel.AutoSize = true;
            this.oznakaOdabranogLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oznakaOdabranogLetaLabel.Location = new System.Drawing.Point(158, 22);
            this.oznakaOdabranogLetaLabel.Name = "oznakaOdabranogLetaLabel";
            this.oznakaOdabranogLetaLabel.Size = new System.Drawing.Size(0, 24);
            this.oznakaOdabranogLetaLabel.TabIndex = 31;
            // 
            // detaljiLetaLabel
            // 
            this.detaljiLetaLabel.AutoSize = true;
            this.detaljiLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.detaljiLetaLabel.Location = new System.Drawing.Point(46, 22);
            this.detaljiLetaLabel.Name = "detaljiLetaLabel";
            this.detaljiLetaLabel.Size = new System.Drawing.Size(106, 24);
            this.detaljiLetaLabel.TabIndex = 30;
            this.detaljiLetaLabel.Text = "Detalji leta";
            // 
            // obrisiLetButton
            // 
            this.obrisiLetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obrisiLetButton.Location = new System.Drawing.Point(63, 390);
            this.obrisiLetButton.Name = "obrisiLetButton";
            this.obrisiLetButton.Size = new System.Drawing.Size(89, 34);
            this.obrisiLetButton.TabIndex = 45;
            this.obrisiLetButton.Text = "Obriši let";
            this.obrisiLetButton.UseVisualStyleBackColor = true;
            this.obrisiLetButton.Click += new System.EventHandler(this.obrisiLetButton_Click);
            // 
            // FormObrisiLet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 455);
            this.Controls.Add(this.obrisiLetButton);
            this.Controls.Add(this.odustaniButton);
            this.Controls.Add(this.vrijemeDolaskaTextBox);
            this.Controls.Add(this.vrijemeDolaskaLabel);
            this.Controls.Add(this.vrijemePolaskaTextBox);
            this.Controls.Add(this.vrijemePolaskaLabel);
            this.Controls.Add(this.avionNaLetuTextBox);
            this.Controls.Add(this.avionNaLetuLabel);
            this.Controls.Add(this.odabraniOdredisniTextBox);
            this.Controls.Add(this.odabraniOdredisniLabel);
            this.Controls.Add(this.odabraniPolazisniTextBox);
            this.Controls.Add(this.odabraniPolazisniLabel);
            this.Controls.Add(this.oznakaOdabranogLetaLabel);
            this.Controls.Add(this.detaljiLetaLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormObrisiLet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Obrisi let";
            this.Load += new System.EventHandler(this.FormObrisiLet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button odustaniButton;
        private System.Windows.Forms.TextBox vrijemeDolaskaTextBox;
        private System.Windows.Forms.Label vrijemeDolaskaLabel;
        private System.Windows.Forms.TextBox vrijemePolaskaTextBox;
        private System.Windows.Forms.Label vrijemePolaskaLabel;
        private System.Windows.Forms.TextBox avionNaLetuTextBox;
        private System.Windows.Forms.Label avionNaLetuLabel;
        private System.Windows.Forms.TextBox odabraniOdredisniTextBox;
        private System.Windows.Forms.Label odabraniOdredisniLabel;
        private System.Windows.Forms.TextBox odabraniPolazisniTextBox;
        private System.Windows.Forms.Label odabraniPolazisniLabel;
        private System.Windows.Forms.Label oznakaOdabranogLetaLabel;
        private System.Windows.Forms.Label detaljiLetaLabel;
        private System.Windows.Forms.Button obrisiLetButton;
    }
}