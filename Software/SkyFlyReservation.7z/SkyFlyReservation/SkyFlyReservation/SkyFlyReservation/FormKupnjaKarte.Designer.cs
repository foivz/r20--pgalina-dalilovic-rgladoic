﻿namespace SkyFlyReservation
{
    partial class FormKupnjaKarte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormKupnjaKarte));
            this.A30 = new System.Windows.Forms.TextBox();
            this.A29 = new System.Windows.Forms.TextBox();
            this.A28 = new System.Windows.Forms.TextBox();
            this.A27 = new System.Windows.Forms.TextBox();
            this.A26 = new System.Windows.Forms.TextBox();
            this.A25 = new System.Windows.Forms.TextBox();
            this.A24 = new System.Windows.Forms.TextBox();
            this.A23 = new System.Windows.Forms.TextBox();
            this.A22 = new System.Windows.Forms.TextBox();
            this.A21 = new System.Windows.Forms.TextBox();
            this.A20 = new System.Windows.Forms.TextBox();
            this.A19 = new System.Windows.Forms.TextBox();
            this.A18 = new System.Windows.Forms.TextBox();
            this.A17 = new System.Windows.Forms.TextBox();
            this.A16 = new System.Windows.Forms.TextBox();
            this.A15 = new System.Windows.Forms.TextBox();
            this.A14 = new System.Windows.Forms.TextBox();
            this.A13 = new System.Windows.Forms.TextBox();
            this.A12 = new System.Windows.Forms.TextBox();
            this.A11 = new System.Windows.Forms.TextBox();
            this.A10 = new System.Windows.Forms.TextBox();
            this.A9 = new System.Windows.Forms.TextBox();
            this.A8 = new System.Windows.Forms.TextBox();
            this.A7 = new System.Windows.Forms.TextBox();
            this.A6 = new System.Windows.Forms.TextBox();
            this.A5 = new System.Windows.Forms.TextBox();
            this.A4 = new System.Windows.Forms.TextBox();
            this.A3 = new System.Windows.Forms.TextBox();
            this.A2 = new System.Windows.Forms.TextBox();
            this.A1 = new System.Windows.Forms.TextBox();
            this.sjedalaUAvionuPanel = new System.Windows.Forms.Panel();
            this.kupiKartuButton = new System.Windows.Forms.Button();
            this.odaberiteSjedaloLabel = new System.Windows.Forms.Label();
            this.mapaSjedalaAvionaPictureBox = new System.Windows.Forms.PictureBox();
            this.cijenaKarteTextBox = new System.Windows.Forms.TextBox();
            this.cijenaKarteLabel = new System.Windows.Forms.Label();
            this.vrijemeDolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemeDolaskaLabel = new System.Windows.Forms.Label();
            this.vrijemePolaskaTextBox = new System.Windows.Forms.TextBox();
            this.vrijemePolaskaLabel = new System.Windows.Forms.Label();
            this.avionNaLetuTextBox = new System.Windows.Forms.TextBox();
            this.avionNaLetuLabel = new System.Windows.Forms.Label();
            this.odabraniOdredisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniOdredisniLabel = new System.Windows.Forms.Label();
            this.odabraniPolazisniTextBox = new System.Windows.Forms.TextBox();
            this.odabraniPolazisniLabel = new System.Windows.Forms.Label();
            this.oznakaOdabranogLetaLabel = new System.Windows.Forms.Label();
            this.detaljiLetaLabel = new System.Windows.Forms.Label();
            this.sjedalaUAvionuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mapaSjedalaAvionaPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // A30
            // 
            this.A30.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A30.Location = new System.Drawing.Point(219, 3);
            this.A30.Margin = new System.Windows.Forms.Padding(4);
            this.A30.Multiline = true;
            this.A30.Name = "A30";
            this.A30.ReadOnly = true;
            this.A30.Size = new System.Drawing.Size(16, 15);
            this.A30.TabIndex = 48;
            this.A30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A29
            // 
            this.A29.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A29.Location = new System.Drawing.Point(219, 22);
            this.A29.Margin = new System.Windows.Forms.Padding(4);
            this.A29.Multiline = true;
            this.A29.Name = "A29";
            this.A29.ReadOnly = true;
            this.A29.Size = new System.Drawing.Size(16, 15);
            this.A29.TabIndex = 47;
            this.A29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A28
            // 
            this.A28.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A28.Location = new System.Drawing.Point(219, 42);
            this.A28.Margin = new System.Windows.Forms.Padding(4);
            this.A28.Multiline = true;
            this.A28.Name = "A28";
            this.A28.ReadOnly = true;
            this.A28.Size = new System.Drawing.Size(16, 15);
            this.A28.TabIndex = 46;
            this.A28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A27
            // 
            this.A27.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A27.Location = new System.Drawing.Point(195, 3);
            this.A27.Margin = new System.Windows.Forms.Padding(4);
            this.A27.Multiline = true;
            this.A27.Name = "A27";
            this.A27.ReadOnly = true;
            this.A27.Size = new System.Drawing.Size(16, 15);
            this.A27.TabIndex = 45;
            this.A27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A26
            // 
            this.A26.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A26.Location = new System.Drawing.Point(195, 22);
            this.A26.Margin = new System.Windows.Forms.Padding(4);
            this.A26.Multiline = true;
            this.A26.Name = "A26";
            this.A26.ReadOnly = true;
            this.A26.Size = new System.Drawing.Size(16, 15);
            this.A26.TabIndex = 44;
            this.A26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A25
            // 
            this.A25.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A25.Location = new System.Drawing.Point(195, 42);
            this.A25.Margin = new System.Windows.Forms.Padding(4);
            this.A25.Multiline = true;
            this.A25.Name = "A25";
            this.A25.ReadOnly = true;
            this.A25.Size = new System.Drawing.Size(16, 15);
            this.A25.TabIndex = 43;
            this.A25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A24
            // 
            this.A24.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A24.Location = new System.Drawing.Point(171, 3);
            this.A24.Margin = new System.Windows.Forms.Padding(4);
            this.A24.Multiline = true;
            this.A24.Name = "A24";
            this.A24.ReadOnly = true;
            this.A24.Size = new System.Drawing.Size(16, 15);
            this.A24.TabIndex = 42;
            this.A24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A23
            // 
            this.A23.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A23.Location = new System.Drawing.Point(171, 22);
            this.A23.Margin = new System.Windows.Forms.Padding(4);
            this.A23.Multiline = true;
            this.A23.Name = "A23";
            this.A23.ReadOnly = true;
            this.A23.Size = new System.Drawing.Size(16, 15);
            this.A23.TabIndex = 41;
            this.A23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A22
            // 
            this.A22.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A22.Location = new System.Drawing.Point(171, 42);
            this.A22.Margin = new System.Windows.Forms.Padding(4);
            this.A22.Multiline = true;
            this.A22.Name = "A22";
            this.A22.ReadOnly = true;
            this.A22.Size = new System.Drawing.Size(16, 15);
            this.A22.TabIndex = 40;
            this.A22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A21
            // 
            this.A21.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A21.Location = new System.Drawing.Point(147, 3);
            this.A21.Margin = new System.Windows.Forms.Padding(4);
            this.A21.Multiline = true;
            this.A21.Name = "A21";
            this.A21.ReadOnly = true;
            this.A21.Size = new System.Drawing.Size(16, 15);
            this.A21.TabIndex = 39;
            this.A21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A20
            // 
            this.A20.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A20.Location = new System.Drawing.Point(147, 22);
            this.A20.Margin = new System.Windows.Forms.Padding(4);
            this.A20.Multiline = true;
            this.A20.Name = "A20";
            this.A20.ReadOnly = true;
            this.A20.Size = new System.Drawing.Size(16, 15);
            this.A20.TabIndex = 38;
            this.A20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A19
            // 
            this.A19.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A19.Location = new System.Drawing.Point(147, 42);
            this.A19.Margin = new System.Windows.Forms.Padding(4);
            this.A19.Multiline = true;
            this.A19.Name = "A19";
            this.A19.ReadOnly = true;
            this.A19.Size = new System.Drawing.Size(16, 15);
            this.A19.TabIndex = 37;
            this.A19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A18
            // 
            this.A18.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A18.Location = new System.Drawing.Point(124, 3);
            this.A18.Margin = new System.Windows.Forms.Padding(4);
            this.A18.Multiline = true;
            this.A18.Name = "A18";
            this.A18.ReadOnly = true;
            this.A18.Size = new System.Drawing.Size(16, 15);
            this.A18.TabIndex = 36;
            this.A18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A17
            // 
            this.A17.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A17.Location = new System.Drawing.Point(124, 22);
            this.A17.Margin = new System.Windows.Forms.Padding(4);
            this.A17.Multiline = true;
            this.A17.Name = "A17";
            this.A17.ReadOnly = true;
            this.A17.Size = new System.Drawing.Size(16, 15);
            this.A17.TabIndex = 35;
            this.A17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A16
            // 
            this.A16.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A16.Location = new System.Drawing.Point(124, 42);
            this.A16.Margin = new System.Windows.Forms.Padding(4);
            this.A16.Multiline = true;
            this.A16.Name = "A16";
            this.A16.ReadOnly = true;
            this.A16.Size = new System.Drawing.Size(16, 15);
            this.A16.TabIndex = 34;
            this.A16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A15
            // 
            this.A15.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A15.Location = new System.Drawing.Point(100, 3);
            this.A15.Margin = new System.Windows.Forms.Padding(4);
            this.A15.Multiline = true;
            this.A15.Name = "A15";
            this.A15.ReadOnly = true;
            this.A15.Size = new System.Drawing.Size(16, 15);
            this.A15.TabIndex = 33;
            this.A15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A14
            // 
            this.A14.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A14.Location = new System.Drawing.Point(100, 22);
            this.A14.Margin = new System.Windows.Forms.Padding(4);
            this.A14.Multiline = true;
            this.A14.Name = "A14";
            this.A14.ReadOnly = true;
            this.A14.Size = new System.Drawing.Size(16, 15);
            this.A14.TabIndex = 32;
            this.A14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A13
            // 
            this.A13.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A13.Location = new System.Drawing.Point(100, 42);
            this.A13.Margin = new System.Windows.Forms.Padding(4);
            this.A13.Multiline = true;
            this.A13.Name = "A13";
            this.A13.ReadOnly = true;
            this.A13.Size = new System.Drawing.Size(16, 15);
            this.A13.TabIndex = 31;
            this.A13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A12
            // 
            this.A12.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A12.Location = new System.Drawing.Point(76, 3);
            this.A12.Margin = new System.Windows.Forms.Padding(4);
            this.A12.Multiline = true;
            this.A12.Name = "A12";
            this.A12.ReadOnly = true;
            this.A12.Size = new System.Drawing.Size(16, 15);
            this.A12.TabIndex = 30;
            this.A12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A11
            // 
            this.A11.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A11.Location = new System.Drawing.Point(76, 22);
            this.A11.Margin = new System.Windows.Forms.Padding(4);
            this.A11.Multiline = true;
            this.A11.Name = "A11";
            this.A11.ReadOnly = true;
            this.A11.Size = new System.Drawing.Size(16, 15);
            this.A11.TabIndex = 29;
            this.A11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A10
            // 
            this.A10.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A10.Location = new System.Drawing.Point(76, 42);
            this.A10.Margin = new System.Windows.Forms.Padding(4);
            this.A10.Multiline = true;
            this.A10.Name = "A10";
            this.A10.ReadOnly = true;
            this.A10.Size = new System.Drawing.Size(16, 15);
            this.A10.TabIndex = 28;
            this.A10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A9
            // 
            this.A9.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A9.Location = new System.Drawing.Point(52, 3);
            this.A9.Margin = new System.Windows.Forms.Padding(4);
            this.A9.Multiline = true;
            this.A9.Name = "A9";
            this.A9.ReadOnly = true;
            this.A9.Size = new System.Drawing.Size(16, 15);
            this.A9.TabIndex = 27;
            this.A9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A8
            // 
            this.A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A8.Location = new System.Drawing.Point(52, 22);
            this.A8.Margin = new System.Windows.Forms.Padding(4);
            this.A8.Multiline = true;
            this.A8.Name = "A8";
            this.A8.ReadOnly = true;
            this.A8.Size = new System.Drawing.Size(16, 15);
            this.A8.TabIndex = 26;
            this.A8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A7
            // 
            this.A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A7.Location = new System.Drawing.Point(52, 42);
            this.A7.Margin = new System.Windows.Forms.Padding(4);
            this.A7.Multiline = true;
            this.A7.Name = "A7";
            this.A7.ReadOnly = true;
            this.A7.Size = new System.Drawing.Size(16, 15);
            this.A7.TabIndex = 25;
            this.A7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A6
            // 
            this.A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A6.Location = new System.Drawing.Point(28, 3);
            this.A6.Margin = new System.Windows.Forms.Padding(4);
            this.A6.Multiline = true;
            this.A6.Name = "A6";
            this.A6.ReadOnly = true;
            this.A6.Size = new System.Drawing.Size(16, 15);
            this.A6.TabIndex = 24;
            this.A6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A5
            // 
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A5.Location = new System.Drawing.Point(28, 22);
            this.A5.Margin = new System.Windows.Forms.Padding(4);
            this.A5.Multiline = true;
            this.A5.Name = "A5";
            this.A5.ReadOnly = true;
            this.A5.Size = new System.Drawing.Size(16, 15);
            this.A5.TabIndex = 23;
            this.A5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A4
            // 
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A4.Location = new System.Drawing.Point(28, 42);
            this.A4.Margin = new System.Windows.Forms.Padding(4);
            this.A4.Multiline = true;
            this.A4.Name = "A4";
            this.A4.ReadOnly = true;
            this.A4.Size = new System.Drawing.Size(16, 15);
            this.A4.TabIndex = 22;
            this.A4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A3.Location = new System.Drawing.Point(4, 3);
            this.A3.Margin = new System.Windows.Forms.Padding(4);
            this.A3.Multiline = true;
            this.A3.Name = "A3";
            this.A3.ReadOnly = true;
            this.A3.Size = new System.Drawing.Size(16, 15);
            this.A3.TabIndex = 21;
            this.A3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A2.Location = new System.Drawing.Point(4, 22);
            this.A2.Margin = new System.Windows.Forms.Padding(4);
            this.A2.Multiline = true;
            this.A2.Name = "A2";
            this.A2.ReadOnly = true;
            this.A2.Size = new System.Drawing.Size(16, 15);
            this.A2.TabIndex = 20;
            this.A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 2.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.A1.Location = new System.Drawing.Point(4, 42);
            this.A1.Margin = new System.Windows.Forms.Padding(4);
            this.A1.Multiline = true;
            this.A1.Name = "A1";
            this.A1.ReadOnly = true;
            this.A1.Size = new System.Drawing.Size(16, 15);
            this.A1.TabIndex = 19;
            this.A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // sjedalaUAvionuPanel
            // 
            this.sjedalaUAvionuPanel.Controls.Add(this.A30);
            this.sjedalaUAvionuPanel.Controls.Add(this.A29);
            this.sjedalaUAvionuPanel.Controls.Add(this.A28);
            this.sjedalaUAvionuPanel.Controls.Add(this.A27);
            this.sjedalaUAvionuPanel.Controls.Add(this.A26);
            this.sjedalaUAvionuPanel.Controls.Add(this.A25);
            this.sjedalaUAvionuPanel.Controls.Add(this.A24);
            this.sjedalaUAvionuPanel.Controls.Add(this.A23);
            this.sjedalaUAvionuPanel.Controls.Add(this.A22);
            this.sjedalaUAvionuPanel.Controls.Add(this.A21);
            this.sjedalaUAvionuPanel.Controls.Add(this.A20);
            this.sjedalaUAvionuPanel.Controls.Add(this.A19);
            this.sjedalaUAvionuPanel.Controls.Add(this.A18);
            this.sjedalaUAvionuPanel.Controls.Add(this.A17);
            this.sjedalaUAvionuPanel.Controls.Add(this.A16);
            this.sjedalaUAvionuPanel.Controls.Add(this.A15);
            this.sjedalaUAvionuPanel.Controls.Add(this.A14);
            this.sjedalaUAvionuPanel.Controls.Add(this.A13);
            this.sjedalaUAvionuPanel.Controls.Add(this.A12);
            this.sjedalaUAvionuPanel.Controls.Add(this.A11);
            this.sjedalaUAvionuPanel.Controls.Add(this.A10);
            this.sjedalaUAvionuPanel.Controls.Add(this.A9);
            this.sjedalaUAvionuPanel.Controls.Add(this.A8);
            this.sjedalaUAvionuPanel.Controls.Add(this.A7);
            this.sjedalaUAvionuPanel.Controls.Add(this.A6);
            this.sjedalaUAvionuPanel.Controls.Add(this.A5);
            this.sjedalaUAvionuPanel.Controls.Add(this.A4);
            this.sjedalaUAvionuPanel.Controls.Add(this.A3);
            this.sjedalaUAvionuPanel.Controls.Add(this.A2);
            this.sjedalaUAvionuPanel.Controls.Add(this.A1);
            this.sjedalaUAvionuPanel.Location = new System.Drawing.Point(380, 194);
            this.sjedalaUAvionuPanel.Name = "sjedalaUAvionuPanel";
            this.sjedalaUAvionuPanel.Size = new System.Drawing.Size(310, 60);
            this.sjedalaUAvionuPanel.TabIndex = 36;
            // 
            // kupiKartuButton
            // 
            this.kupiKartuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kupiKartuButton.Location = new System.Drawing.Point(685, 385);
            this.kupiKartuButton.Name = "kupiKartuButton";
            this.kupiKartuButton.Size = new System.Drawing.Size(98, 42);
            this.kupiKartuButton.TabIndex = 35;
            this.kupiKartuButton.Text = "Kupi kartu";
            this.kupiKartuButton.UseVisualStyleBackColor = true;
            this.kupiKartuButton.Click += new System.EventHandler(this.kupiKartuButton_Click);
            // 
            // odaberiteSjedaloLabel
            // 
            this.odaberiteSjedaloLabel.AutoSize = true;
            this.odaberiteSjedaloLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odaberiteSjedaloLabel.Location = new System.Drawing.Point(259, 65);
            this.odaberiteSjedaloLabel.Name = "odaberiteSjedaloLabel";
            this.odaberiteSjedaloLabel.Size = new System.Drawing.Size(150, 18);
            this.odaberiteSjedaloLabel.TabIndex = 34;
            this.odaberiteSjedaloLabel.Text = "Odaberite sjedalo :";
            // 
            // mapaSjedalaAvionaPictureBox
            // 
            this.mapaSjedalaAvionaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("mapaSjedalaAvionaPictureBox.Image")));
            this.mapaSjedalaAvionaPictureBox.Location = new System.Drawing.Point(259, 88);
            this.mapaSjedalaAvionaPictureBox.Name = "mapaSjedalaAvionaPictureBox";
            this.mapaSjedalaAvionaPictureBox.Size = new System.Drawing.Size(524, 291);
            this.mapaSjedalaAvionaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mapaSjedalaAvionaPictureBox.TabIndex = 33;
            this.mapaSjedalaAvionaPictureBox.TabStop = false;
            // 
            // cijenaKarteTextBox
            // 
            this.cijenaKarteTextBox.Enabled = false;
            this.cijenaKarteTextBox.Location = new System.Drawing.Point(22, 405);
            this.cijenaKarteTextBox.Name = "cijenaKarteTextBox";
            this.cijenaKarteTextBox.ReadOnly = true;
            this.cijenaKarteTextBox.Size = new System.Drawing.Size(200, 22);
            this.cijenaKarteTextBox.TabIndex = 32;
            // 
            // cijenaKarteLabel
            // 
            this.cijenaKarteLabel.AutoSize = true;
            this.cijenaKarteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cijenaKarteLabel.Location = new System.Drawing.Point(19, 385);
            this.cijenaKarteLabel.Name = "cijenaKarteLabel";
            this.cijenaKarteLabel.Size = new System.Drawing.Size(91, 17);
            this.cijenaKarteLabel.TabIndex = 31;
            this.cijenaKarteLabel.Text = "Cijena karte :";
            // 
            // vrijemeDolaskaTextBox
            // 
            this.vrijemeDolaskaTextBox.Enabled = false;
            this.vrijemeDolaskaTextBox.Location = new System.Drawing.Point(22, 342);
            this.vrijemeDolaskaTextBox.Name = "vrijemeDolaskaTextBox";
            this.vrijemeDolaskaTextBox.ReadOnly = true;
            this.vrijemeDolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemeDolaskaTextBox.TabIndex = 30;
            // 
            // vrijemeDolaskaLabel
            // 
            this.vrijemeDolaskaLabel.AutoSize = true;
            this.vrijemeDolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemeDolaskaLabel.Location = new System.Drawing.Point(19, 321);
            this.vrijemeDolaskaLabel.Name = "vrijemeDolaskaLabel";
            this.vrijemeDolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemeDolaskaLabel.TabIndex = 29;
            this.vrijemeDolaskaLabel.Text = "Vrijeme dolaska :";
            // 
            // vrijemePolaskaTextBox
            // 
            this.vrijemePolaskaTextBox.Enabled = false;
            this.vrijemePolaskaTextBox.Location = new System.Drawing.Point(22, 278);
            this.vrijemePolaskaTextBox.Name = "vrijemePolaskaTextBox";
            this.vrijemePolaskaTextBox.ReadOnly = true;
            this.vrijemePolaskaTextBox.Size = new System.Drawing.Size(200, 22);
            this.vrijemePolaskaTextBox.TabIndex = 28;
            // 
            // vrijemePolaskaLabel
            // 
            this.vrijemePolaskaLabel.AutoSize = true;
            this.vrijemePolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemePolaskaLabel.Location = new System.Drawing.Point(19, 258);
            this.vrijemePolaskaLabel.Name = "vrijemePolaskaLabel";
            this.vrijemePolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemePolaskaLabel.TabIndex = 27;
            this.vrijemePolaskaLabel.Text = "Vrijeme polaska :";
            // 
            // avionNaLetuTextBox
            // 
            this.avionNaLetuTextBox.Enabled = false;
            this.avionNaLetuTextBox.Location = new System.Drawing.Point(22, 214);
            this.avionNaLetuTextBox.Name = "avionNaLetuTextBox";
            this.avionNaLetuTextBox.ReadOnly = true;
            this.avionNaLetuTextBox.Size = new System.Drawing.Size(200, 22);
            this.avionNaLetuTextBox.TabIndex = 26;
            // 
            // avionNaLetuLabel
            // 
            this.avionNaLetuLabel.AutoSize = true;
            this.avionNaLetuLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.avionNaLetuLabel.Location = new System.Drawing.Point(19, 194);
            this.avionNaLetuLabel.Name = "avionNaLetuLabel";
            this.avionNaLetuLabel.Size = new System.Drawing.Size(98, 17);
            this.avionNaLetuLabel.TabIndex = 25;
            this.avionNaLetuLabel.Text = "Avion na letu :";
            // 
            // odabraniOdredisniTextBox
            // 
            this.odabraniOdredisniTextBox.Enabled = false;
            this.odabraniOdredisniTextBox.Location = new System.Drawing.Point(22, 151);
            this.odabraniOdredisniTextBox.Name = "odabraniOdredisniTextBox";
            this.odabraniOdredisniTextBox.ReadOnly = true;
            this.odabraniOdredisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniOdredisniTextBox.TabIndex = 24;
            // 
            // odabraniOdredisniLabel
            // 
            this.odabraniOdredisniLabel.AutoSize = true;
            this.odabraniOdredisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniOdredisniLabel.Location = new System.Drawing.Point(19, 130);
            this.odabraniOdredisniLabel.Name = "odabraniOdredisniLabel";
            this.odabraniOdredisniLabel.Size = new System.Drawing.Size(142, 17);
            this.odabraniOdredisniLabel.TabIndex = 23;
            this.odabraniOdredisniLabel.Text = "Odredišni aerodrom :";
            // 
            // odabraniPolazisniTextBox
            // 
            this.odabraniPolazisniTextBox.Enabled = false;
            this.odabraniPolazisniTextBox.Location = new System.Drawing.Point(22, 88);
            this.odabraniPolazisniTextBox.Name = "odabraniPolazisniTextBox";
            this.odabraniPolazisniTextBox.ReadOnly = true;
            this.odabraniPolazisniTextBox.Size = new System.Drawing.Size(200, 22);
            this.odabraniPolazisniTextBox.TabIndex = 22;
            // 
            // odabraniPolazisniLabel
            // 
            this.odabraniPolazisniLabel.AutoSize = true;
            this.odabraniPolazisniLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odabraniPolazisniLabel.Location = new System.Drawing.Point(19, 67);
            this.odabraniPolazisniLabel.Name = "odabraniPolazisniLabel";
            this.odabraniPolazisniLabel.Size = new System.Drawing.Size(137, 17);
            this.odabraniPolazisniLabel.TabIndex = 21;
            this.odabraniPolazisniLabel.Text = "Polazišni aerodrom :";
            // 
            // oznakaOdabranogLetaLabel
            // 
            this.oznakaOdabranogLetaLabel.AutoSize = true;
            this.oznakaOdabranogLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oznakaOdabranogLetaLabel.Location = new System.Drawing.Point(130, 24);
            this.oznakaOdabranogLetaLabel.Name = "oznakaOdabranogLetaLabel";
            this.oznakaOdabranogLetaLabel.Size = new System.Drawing.Size(0, 24);
            this.oznakaOdabranogLetaLabel.TabIndex = 20;
            // 
            // detaljiLetaLabel
            // 
            this.detaljiLetaLabel.AutoSize = true;
            this.detaljiLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.detaljiLetaLabel.Location = new System.Drawing.Point(18, 24);
            this.detaljiLetaLabel.Name = "detaljiLetaLabel";
            this.detaljiLetaLabel.Size = new System.Drawing.Size(106, 24);
            this.detaljiLetaLabel.TabIndex = 19;
            this.detaljiLetaLabel.Text = "Detalji leta";
            // 
            // FormKupnjaKarte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.sjedalaUAvionuPanel);
            this.Controls.Add(this.kupiKartuButton);
            this.Controls.Add(this.odaberiteSjedaloLabel);
            this.Controls.Add(this.mapaSjedalaAvionaPictureBox);
            this.Controls.Add(this.cijenaKarteTextBox);
            this.Controls.Add(this.cijenaKarteLabel);
            this.Controls.Add(this.vrijemeDolaskaTextBox);
            this.Controls.Add(this.vrijemeDolaskaLabel);
            this.Controls.Add(this.vrijemePolaskaTextBox);
            this.Controls.Add(this.vrijemePolaskaLabel);
            this.Controls.Add(this.avionNaLetuTextBox);
            this.Controls.Add(this.avionNaLetuLabel);
            this.Controls.Add(this.odabraniOdredisniTextBox);
            this.Controls.Add(this.odabraniOdredisniLabel);
            this.Controls.Add(this.odabraniPolazisniTextBox);
            this.Controls.Add(this.odabraniPolazisniLabel);
            this.Controls.Add(this.oznakaOdabranogLetaLabel);
            this.Controls.Add(this.detaljiLetaLabel);
            this.Name = "FormKupnjaKarte";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kupnja karte";
            this.Load += new System.EventHandler(this.FormKupnjaKarte_Load);
            this.sjedalaUAvionuPanel.ResumeLayout(false);
            this.sjedalaUAvionuPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mapaSjedalaAvionaPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox A30;
        private System.Windows.Forms.TextBox A29;
        private System.Windows.Forms.TextBox A28;
        private System.Windows.Forms.TextBox A27;
        private System.Windows.Forms.TextBox A26;
        private System.Windows.Forms.TextBox A25;
        private System.Windows.Forms.TextBox A24;
        private System.Windows.Forms.TextBox A23;
        private System.Windows.Forms.TextBox A22;
        private System.Windows.Forms.TextBox A21;
        private System.Windows.Forms.TextBox A20;
        private System.Windows.Forms.TextBox A19;
        private System.Windows.Forms.TextBox A18;
        private System.Windows.Forms.TextBox A17;
        private System.Windows.Forms.TextBox A16;
        private System.Windows.Forms.TextBox A15;
        private System.Windows.Forms.TextBox A14;
        private System.Windows.Forms.TextBox A13;
        private System.Windows.Forms.TextBox A12;
        private System.Windows.Forms.TextBox A11;
        private System.Windows.Forms.TextBox A10;
        private System.Windows.Forms.TextBox A9;
        private System.Windows.Forms.TextBox A8;
        private System.Windows.Forms.TextBox A7;
        private System.Windows.Forms.TextBox A6;
        private System.Windows.Forms.TextBox A5;
        private System.Windows.Forms.TextBox A4;
        private System.Windows.Forms.TextBox A3;
        private System.Windows.Forms.TextBox A2;
        private System.Windows.Forms.TextBox A1;
        private System.Windows.Forms.Panel sjedalaUAvionuPanel;
        private System.Windows.Forms.Button kupiKartuButton;
        private System.Windows.Forms.Label odaberiteSjedaloLabel;
        private System.Windows.Forms.PictureBox mapaSjedalaAvionaPictureBox;
        private System.Windows.Forms.TextBox cijenaKarteTextBox;
        private System.Windows.Forms.Label cijenaKarteLabel;
        private System.Windows.Forms.TextBox vrijemeDolaskaTextBox;
        private System.Windows.Forms.Label vrijemeDolaskaLabel;
        private System.Windows.Forms.TextBox vrijemePolaskaTextBox;
        private System.Windows.Forms.Label vrijemePolaskaLabel;
        private System.Windows.Forms.TextBox avionNaLetuTextBox;
        private System.Windows.Forms.Label avionNaLetuLabel;
        private System.Windows.Forms.TextBox odabraniOdredisniTextBox;
        private System.Windows.Forms.Label odabraniOdredisniLabel;
        private System.Windows.Forms.TextBox odabraniPolazisniTextBox;
        private System.Windows.Forms.Label odabraniPolazisniLabel;
        private System.Windows.Forms.Label oznakaOdabranogLetaLabel;
        private System.Windows.Forms.Label detaljiLetaLabel;
    }
}