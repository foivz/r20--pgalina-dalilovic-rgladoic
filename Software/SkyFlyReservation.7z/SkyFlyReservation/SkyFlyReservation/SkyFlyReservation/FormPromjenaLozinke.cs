﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkyFlyReservation
{
    public partial class FormPromjenaLozinke : Form
    {
        public FormPromjenaLozinke()
        {
            InitializeComponent();
        }

        private void LozinkaLabel_Click(object sender, EventArgs e)
        {

        }

        private void PonovljenaLozinkaLabel_Click(object sender, EventArgs e)
        {

        }

        private void PonovljenaLozinkaTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void LozinkaTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegistrirajSeButton_Click(object sender, EventArgs e)
        {

        }

        private void NatragButton_Click(object sender, EventArgs e)
        {

        }
    }
}
