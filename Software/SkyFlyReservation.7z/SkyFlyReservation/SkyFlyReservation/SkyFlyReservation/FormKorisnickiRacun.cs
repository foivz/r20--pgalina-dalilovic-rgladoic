﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkyFlyReservation
{
    public partial class FormKorisnickiRacun : Form
    {
        public FormKorisnickiRacun()
        {
            InitializeComponent();
        }

        private void SpremiPromjeneButton_Click(object sender, EventArgs e)
        {

        }

        private void NatragButton_Click(object sender, EventArgs e)
        {

        }
    }
}
