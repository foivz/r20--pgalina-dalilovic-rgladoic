﻿namespace SkyFlyReservation
{
    partial class FormRegistracija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KontaktLabel = new System.Windows.Forms.Label();
            this.KontaktTextBox = new System.Windows.Forms.TextBox();
            this.NatragButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.RegistrirajSeButton = new System.Windows.Forms.Button();
            this.PonovljenaLozinkaTextBox = new System.Windows.Forms.TextBox();
            this.PonovljenaLozinkaLabel = new System.Windows.Forms.Label();
            this.LozinkaTextBox = new System.Windows.Forms.TextBox();
            this.LozinkaLabel = new System.Windows.Forms.Label();
            this.KorImeTextBox = new System.Windows.Forms.TextBox();
            this.KorImeLabel = new System.Windows.Forms.Label();
            this.AdresaTextBox = new System.Windows.Forms.TextBox();
            this.AdresaLabel = new System.Windows.Forms.Label();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PrezimeTextBox = new System.Windows.Forms.TextBox();
            this.PrezimeLabel = new System.Windows.Forms.Label();
            this.ImeTextBox = new System.Windows.Forms.TextBox();
            this.ImeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // KontaktLabel
            // 
            this.KontaktLabel.AutoSize = true;
            this.KontaktLabel.Location = new System.Drawing.Point(268, 220);
            this.KontaktLabel.Name = "KontaktLabel";
            this.KontaktLabel.Size = new System.Drawing.Size(47, 13);
            this.KontaktLabel.TabIndex = 53;
            this.KontaktLabel.Text = "Kontakt:";
            // 
            // KontaktTextBox
            // 
            this.KontaktTextBox.Location = new System.Drawing.Point(322, 217);
            this.KontaktTextBox.Name = "KontaktTextBox";
            this.KontaktTextBox.Size = new System.Drawing.Size(197, 20);
            this.KontaktTextBox.TabIndex = 52;
            // 
            // NatragButton
            // 
            this.NatragButton.Location = new System.Drawing.Point(425, 334);
            this.NatragButton.Name = "NatragButton";
            this.NatragButton.Size = new System.Drawing.Size(94, 35);
            this.NatragButton.TabIndex = 51;
            this.NatragButton.Text = "Natrag";
            this.NatragButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(366, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 50;
            this.label1.Text = "Registracija";
            // 
            // RegistrirajSeButton
            // 
            this.RegistrirajSeButton.Location = new System.Drawing.Point(323, 334);
            this.RegistrirajSeButton.Name = "RegistrirajSeButton";
            this.RegistrirajSeButton.Size = new System.Drawing.Size(94, 35);
            this.RegistrirajSeButton.TabIndex = 49;
            this.RegistrirajSeButton.Text = "Registriraj se";
            this.RegistrirajSeButton.UseVisualStyleBackColor = true;
            // 
            // PonovljenaLozinkaTextBox
            // 
            this.PonovljenaLozinkaTextBox.Location = new System.Drawing.Point(322, 295);
            this.PonovljenaLozinkaTextBox.Name = "PonovljenaLozinkaTextBox";
            this.PonovljenaLozinkaTextBox.Size = new System.Drawing.Size(197, 20);
            this.PonovljenaLozinkaTextBox.TabIndex = 48;
            // 
            // PonovljenaLozinkaLabel
            // 
            this.PonovljenaLozinkaLabel.AutoSize = true;
            this.PonovljenaLozinkaLabel.Location = new System.Drawing.Point(221, 298);
            this.PonovljenaLozinkaLabel.Name = "PonovljenaLozinkaLabel";
            this.PonovljenaLozinkaLabel.Size = new System.Drawing.Size(99, 13);
            this.PonovljenaLozinkaLabel.TabIndex = 45;
            this.PonovljenaLozinkaLabel.Text = "Ponovljena lozinka:";
            // 
            // LozinkaTextBox
            // 
            this.LozinkaTextBox.Location = new System.Drawing.Point(322, 269);
            this.LozinkaTextBox.Name = "LozinkaTextBox";
            this.LozinkaTextBox.Size = new System.Drawing.Size(197, 20);
            this.LozinkaTextBox.TabIndex = 47;
            // 
            // LozinkaLabel
            // 
            this.LozinkaLabel.AutoSize = true;
            this.LozinkaLabel.Location = new System.Drawing.Point(269, 272);
            this.LozinkaLabel.Name = "LozinkaLabel";
            this.LozinkaLabel.Size = new System.Drawing.Size(47, 13);
            this.LozinkaLabel.TabIndex = 46;
            this.LozinkaLabel.Text = "Lozinka:";
            // 
            // KorImeTextBox
            // 
            this.KorImeTextBox.Location = new System.Drawing.Point(322, 243);
            this.KorImeTextBox.Name = "KorImeTextBox";
            this.KorImeTextBox.Size = new System.Drawing.Size(197, 20);
            this.KorImeTextBox.TabIndex = 44;
            // 
            // KorImeLabel
            // 
            this.KorImeLabel.AutoSize = true;
            this.KorImeLabel.Location = new System.Drawing.Point(238, 246);
            this.KorImeLabel.Name = "KorImeLabel";
            this.KorImeLabel.Size = new System.Drawing.Size(78, 13);
            this.KorImeLabel.TabIndex = 43;
            this.KorImeLabel.Text = "Korisničko ime:";
            // 
            // AdresaTextBox
            // 
            this.AdresaTextBox.Location = new System.Drawing.Point(322, 191);
            this.AdresaTextBox.Name = "AdresaTextBox";
            this.AdresaTextBox.Size = new System.Drawing.Size(197, 20);
            this.AdresaTextBox.TabIndex = 42;
            // 
            // AdresaLabel
            // 
            this.AdresaLabel.AutoSize = true;
            this.AdresaLabel.Location = new System.Drawing.Point(273, 194);
            this.AdresaLabel.Name = "AdresaLabel";
            this.AdresaLabel.Size = new System.Drawing.Size(43, 13);
            this.AdresaLabel.TabIndex = 41;
            this.AdresaLabel.Text = "Adresa:";
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Location = new System.Drawing.Point(322, 165);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(197, 20);
            this.EmailTextBox.TabIndex = 40;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(281, 168);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(35, 13);
            this.EmailLabel.TabIndex = 39;
            this.EmailLabel.Text = "Email:";
            // 
            // PrezimeTextBox
            // 
            this.PrezimeTextBox.Location = new System.Drawing.Point(323, 139);
            this.PrezimeTextBox.Name = "PrezimeTextBox";
            this.PrezimeTextBox.Size = new System.Drawing.Size(197, 20);
            this.PrezimeTextBox.TabIndex = 38;
            // 
            // PrezimeLabel
            // 
            this.PrezimeLabel.AutoSize = true;
            this.PrezimeLabel.Location = new System.Drawing.Point(269, 142);
            this.PrezimeLabel.Name = "PrezimeLabel";
            this.PrezimeLabel.Size = new System.Drawing.Size(47, 13);
            this.PrezimeLabel.TabIndex = 37;
            this.PrezimeLabel.Text = "Prezime:";
            // 
            // ImeTextBox
            // 
            this.ImeTextBox.Location = new System.Drawing.Point(322, 113);
            this.ImeTextBox.Name = "ImeTextBox";
            this.ImeTextBox.Size = new System.Drawing.Size(197, 20);
            this.ImeTextBox.TabIndex = 36;
            // 
            // ImeLabel
            // 
            this.ImeLabel.AutoSize = true;
            this.ImeLabel.Location = new System.Drawing.Point(289, 116);
            this.ImeLabel.Name = "ImeLabel";
            this.ImeLabel.Size = new System.Drawing.Size(27, 13);
            this.ImeLabel.TabIndex = 35;
            this.ImeLabel.Text = "Ime:";
            // 
            // FormRegistracija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.KontaktLabel);
            this.Controls.Add(this.KontaktTextBox);
            this.Controls.Add(this.NatragButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RegistrirajSeButton);
            this.Controls.Add(this.PonovljenaLozinkaTextBox);
            this.Controls.Add(this.PonovljenaLozinkaLabel);
            this.Controls.Add(this.LozinkaTextBox);
            this.Controls.Add(this.LozinkaLabel);
            this.Controls.Add(this.KorImeTextBox);
            this.Controls.Add(this.KorImeLabel);
            this.Controls.Add(this.AdresaTextBox);
            this.Controls.Add(this.AdresaLabel);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.PrezimeTextBox);
            this.Controls.Add(this.PrezimeLabel);
            this.Controls.Add(this.ImeTextBox);
            this.Controls.Add(this.ImeLabel);
            this.Name = "FormRegistracija";
            this.Text = "FormRegistracija";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label KontaktLabel;
        private System.Windows.Forms.TextBox KontaktTextBox;
        private System.Windows.Forms.Button NatragButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button RegistrirajSeButton;
        private System.Windows.Forms.TextBox PonovljenaLozinkaTextBox;
        private System.Windows.Forms.Label PonovljenaLozinkaLabel;
        private System.Windows.Forms.TextBox LozinkaTextBox;
        private System.Windows.Forms.Label LozinkaLabel;
        private System.Windows.Forms.TextBox KorImeTextBox;
        private System.Windows.Forms.Label KorImeLabel;
        private System.Windows.Forms.TextBox AdresaTextBox;
        private System.Windows.Forms.Label AdresaLabel;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox PrezimeTextBox;
        private System.Windows.Forms.Label PrezimeLabel;
        private System.Windows.Forms.TextBox ImeTextBox;
        private System.Windows.Forms.Label ImeLabel;
    }
}