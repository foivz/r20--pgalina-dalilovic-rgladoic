﻿namespace SkyFlyReservation
{
    partial class FormAzurirajLet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAzurirajLet));
            this.odustaniButton = new System.Windows.Forms.Button();
            this.cijenaKarteLabel = new System.Windows.Forms.Label();
            this.vrijemeDolaskaLabel = new System.Windows.Forms.Label();
            this.vrijemePolaskaLabel = new System.Windows.Forms.Label();
            this.avionNaLetuLabel = new System.Windows.Forms.Label();
            this.odredisniAerodromLabel = new System.Windows.Forms.Label();
            this.polazisniAerodromLabel = new System.Windows.Forms.Label();
            this.oznakaOdabranogLetaLabel = new System.Windows.Forms.Label();
            this.detaljiLetaLabel = new System.Windows.Forms.Label();
            this.azurirajLetButton = new System.Windows.Forms.Button();
            this.polazisniComboBox = new System.Windows.Forms.ComboBox();
            this.odredisniComboBox = new System.Windows.Forms.ComboBox();
            this.avionNaLetuComboBox = new System.Windows.Forms.ComboBox();
            this.datumVrijemePolaskaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.datumVrijemeDolaskaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.valutaComboBox = new System.Windows.Forms.ComboBox();
            this.cijenaKarteTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // odustaniButton
            // 
            this.odustaniButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odustaniButton.Location = new System.Drawing.Point(218, 445);
            this.odustaniButton.Name = "odustaniButton";
            this.odustaniButton.Size = new System.Drawing.Size(89, 43);
            this.odustaniButton.TabIndex = 44;
            this.odustaniButton.Text = "Odustani";
            this.odustaniButton.UseVisualStyleBackColor = true;
            this.odustaniButton.Click += new System.EventHandler(this.odustaniButton_Click);
            // 
            // cijenaKarteLabel
            // 
            this.cijenaKarteLabel.AutoSize = true;
            this.cijenaKarteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cijenaKarteLabel.Location = new System.Drawing.Point(75, 387);
            this.cijenaKarteLabel.Name = "cijenaKarteLabel";
            this.cijenaKarteLabel.Size = new System.Drawing.Size(91, 17);
            this.cijenaKarteLabel.TabIndex = 42;
            this.cijenaKarteLabel.Text = "Cijena karte :";
            // 
            // vrijemeDolaskaLabel
            // 
            this.vrijemeDolaskaLabel.AutoSize = true;
            this.vrijemeDolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemeDolaskaLabel.Location = new System.Drawing.Point(75, 323);
            this.vrijemeDolaskaLabel.Name = "vrijemeDolaskaLabel";
            this.vrijemeDolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemeDolaskaLabel.TabIndex = 40;
            this.vrijemeDolaskaLabel.Text = "Vrijeme dolaska :";
            // 
            // vrijemePolaskaLabel
            // 
            this.vrijemePolaskaLabel.AutoSize = true;
            this.vrijemePolaskaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vrijemePolaskaLabel.Location = new System.Drawing.Point(75, 260);
            this.vrijemePolaskaLabel.Name = "vrijemePolaskaLabel";
            this.vrijemePolaskaLabel.Size = new System.Drawing.Size(116, 17);
            this.vrijemePolaskaLabel.TabIndex = 38;
            this.vrijemePolaskaLabel.Text = "Vrijeme polaska :";
            // 
            // avionNaLetuLabel
            // 
            this.avionNaLetuLabel.AutoSize = true;
            this.avionNaLetuLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.avionNaLetuLabel.Location = new System.Drawing.Point(75, 196);
            this.avionNaLetuLabel.Name = "avionNaLetuLabel";
            this.avionNaLetuLabel.Size = new System.Drawing.Size(98, 17);
            this.avionNaLetuLabel.TabIndex = 36;
            this.avionNaLetuLabel.Text = "Avion na letu :";
            // 
            // odredisniAerodromLabel
            // 
            this.odredisniAerodromLabel.AutoSize = true;
            this.odredisniAerodromLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odredisniAerodromLabel.Location = new System.Drawing.Point(75, 132);
            this.odredisniAerodromLabel.Name = "odredisniAerodromLabel";
            this.odredisniAerodromLabel.Size = new System.Drawing.Size(142, 17);
            this.odredisniAerodromLabel.TabIndex = 34;
            this.odredisniAerodromLabel.Text = "Odredišni aerodrom :";
            // 
            // polazisniAerodromLabel
            // 
            this.polazisniAerodromLabel.AutoSize = true;
            this.polazisniAerodromLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.polazisniAerodromLabel.Location = new System.Drawing.Point(75, 69);
            this.polazisniAerodromLabel.Name = "polazisniAerodromLabel";
            this.polazisniAerodromLabel.Size = new System.Drawing.Size(137, 17);
            this.polazisniAerodromLabel.TabIndex = 32;
            this.polazisniAerodromLabel.Text = "Polazišni aerodrom :";
            // 
            // oznakaOdabranogLetaLabel
            // 
            this.oznakaOdabranogLetaLabel.AutoSize = true;
            this.oznakaOdabranogLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oznakaOdabranogLetaLabel.Location = new System.Drawing.Point(173, 26);
            this.oznakaOdabranogLetaLabel.Name = "oznakaOdabranogLetaLabel";
            this.oznakaOdabranogLetaLabel.Size = new System.Drawing.Size(0, 24);
            this.oznakaOdabranogLetaLabel.TabIndex = 31;
            // 
            // detaljiLetaLabel
            // 
            this.detaljiLetaLabel.AutoSize = true;
            this.detaljiLetaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.detaljiLetaLabel.Location = new System.Drawing.Point(61, 26);
            this.detaljiLetaLabel.Name = "detaljiLetaLabel";
            this.detaljiLetaLabel.Size = new System.Drawing.Size(106, 24);
            this.detaljiLetaLabel.TabIndex = 30;
            this.detaljiLetaLabel.Text = "Detalji leta";
            // 
            // azurirajLetButton
            // 
            this.azurirajLetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.azurirajLetButton.Location = new System.Drawing.Point(78, 445);
            this.azurirajLetButton.Name = "azurirajLetButton";
            this.azurirajLetButton.Size = new System.Drawing.Size(89, 43);
            this.azurirajLetButton.TabIndex = 45;
            this.azurirajLetButton.Text = "Ažuriraj let";
            this.azurirajLetButton.UseVisualStyleBackColor = true;
            this.azurirajLetButton.Click += new System.EventHandler(this.azurirajLetButton_Click);
            // 
            // polazisniComboBox
            // 
            this.polazisniComboBox.FormattingEnabled = true;
            this.polazisniComboBox.Location = new System.Drawing.Point(78, 90);
            this.polazisniComboBox.Name = "polazisniComboBox";
            this.polazisniComboBox.Size = new System.Drawing.Size(229, 24);
            this.polazisniComboBox.TabIndex = 46;
            // 
            // odredisniComboBox
            // 
            this.odredisniComboBox.FormattingEnabled = true;
            this.odredisniComboBox.Location = new System.Drawing.Point(78, 152);
            this.odredisniComboBox.Name = "odredisniComboBox";
            this.odredisniComboBox.Size = new System.Drawing.Size(229, 24);
            this.odredisniComboBox.TabIndex = 47;
            // 
            // avionNaLetuComboBox
            // 
            this.avionNaLetuComboBox.FormattingEnabled = true;
            this.avionNaLetuComboBox.Location = new System.Drawing.Point(78, 216);
            this.avionNaLetuComboBox.Name = "avionNaLetuComboBox";
            this.avionNaLetuComboBox.Size = new System.Drawing.Size(229, 24);
            this.avionNaLetuComboBox.TabIndex = 48;
            // 
            // datumVrijemePolaskaDateTimePicker
            // 
            this.datumVrijemePolaskaDateTimePicker.CustomFormat = "dd. MMMM yyyy., HH:mm:ss";
            this.datumVrijemePolaskaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datumVrijemePolaskaDateTimePicker.Location = new System.Drawing.Point(78, 281);
            this.datumVrijemePolaskaDateTimePicker.Name = "datumVrijemePolaskaDateTimePicker";
            this.datumVrijemePolaskaDateTimePicker.Size = new System.Drawing.Size(229, 22);
            this.datumVrijemePolaskaDateTimePicker.TabIndex = 49;
            // 
            // datumVrijemeDolaskaDateTimePicker
            // 
            this.datumVrijemeDolaskaDateTimePicker.CustomFormat = "dd. MMMM yyyy., HH:mm:ss";
            this.datumVrijemeDolaskaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datumVrijemeDolaskaDateTimePicker.Location = new System.Drawing.Point(78, 344);
            this.datumVrijemeDolaskaDateTimePicker.Name = "datumVrijemeDolaskaDateTimePicker";
            this.datumVrijemeDolaskaDateTimePicker.Size = new System.Drawing.Size(229, 22);
            this.datumVrijemeDolaskaDateTimePicker.TabIndex = 50;
            // 
            // valutaComboBox
            // 
            this.valutaComboBox.FormattingEnabled = true;
            this.valutaComboBox.Location = new System.Drawing.Point(218, 407);
            this.valutaComboBox.Name = "valutaComboBox";
            this.valutaComboBox.Size = new System.Drawing.Size(89, 24);
            this.valutaComboBox.TabIndex = 51;
            // 
            // cijenaKarteTextBox
            // 
            this.cijenaKarteTextBox.Location = new System.Drawing.Point(78, 408);
            this.cijenaKarteTextBox.Name = "cijenaKarteTextBox";
            this.cijenaKarteTextBox.Size = new System.Drawing.Size(113, 22);
            this.cijenaKarteTextBox.TabIndex = 52;
            // 
            // FormAzurirajLet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 512);
            this.Controls.Add(this.cijenaKarteTextBox);
            this.Controls.Add(this.valutaComboBox);
            this.Controls.Add(this.datumVrijemeDolaskaDateTimePicker);
            this.Controls.Add(this.datumVrijemePolaskaDateTimePicker);
            this.Controls.Add(this.avionNaLetuComboBox);
            this.Controls.Add(this.odredisniComboBox);
            this.Controls.Add(this.polazisniComboBox);
            this.Controls.Add(this.azurirajLetButton);
            this.Controls.Add(this.odustaniButton);
            this.Controls.Add(this.cijenaKarteLabel);
            this.Controls.Add(this.vrijemeDolaskaLabel);
            this.Controls.Add(this.vrijemePolaskaLabel);
            this.Controls.Add(this.avionNaLetuLabel);
            this.Controls.Add(this.odredisniAerodromLabel);
            this.Controls.Add(this.polazisniAerodromLabel);
            this.Controls.Add(this.oznakaOdabranogLetaLabel);
            this.Controls.Add(this.detaljiLetaLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAzurirajLet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Azuriraj let";
            this.Load += new System.EventHandler(this.FormAzurirajLet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button odustaniButton;
        private System.Windows.Forms.Label cijenaKarteLabel;
        private System.Windows.Forms.Label vrijemeDolaskaLabel;
        private System.Windows.Forms.Label vrijemePolaskaLabel;
        private System.Windows.Forms.Label avionNaLetuLabel;
        private System.Windows.Forms.Label odredisniAerodromLabel;
        private System.Windows.Forms.Label polazisniAerodromLabel;
        private System.Windows.Forms.Label oznakaOdabranogLetaLabel;
        private System.Windows.Forms.Label detaljiLetaLabel;
        private System.Windows.Forms.Button azurirajLetButton;
        private System.Windows.Forms.ComboBox polazisniComboBox;
        private System.Windows.Forms.ComboBox odredisniComboBox;
        private System.Windows.Forms.ComboBox avionNaLetuComboBox;
        private System.Windows.Forms.DateTimePicker datumVrijemePolaskaDateTimePicker;
        private System.Windows.Forms.DateTimePicker datumVrijemeDolaskaDateTimePicker;
        private System.Windows.Forms.ComboBox valutaComboBox;
        private System.Windows.Forms.TextBox cijenaKarteTextBox;
    }
}